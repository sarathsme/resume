﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace PonyChallenge.API
{

    static class PonyChallengeAPI
    {
        //TODO: Move to config file.
        const string TP_PONY_CHALLENGE_API_URL = "https://ponychallenge.trustpilot.com/pony-challenge/maze";
        private static HttpClient Client = new HttpClient();


        internal static async Task<string> CreateNewChallenge(ChallengeParams challengeParams)
        {
            string mazeId = null;

            StringContent requestBody = new StringContent(JsonConvert.SerializeObject(challengeParams), Encoding.UTF8, "application/json");
            var httpResponse = await Client.PostAsync(TP_PONY_CHALLENGE_API_URL, requestBody);

            if (httpResponse.IsSuccessStatusCode && httpResponse.Content != null)
            {
                string contentStr = await httpResponse.Content.ReadAsStringAsync();
                JObject contentJson = JObject.Parse(contentStr);
                if (contentJson != null && contentJson["maze_id"] != null)
                {
                    mazeId = contentJson["maze_id"].ToString();
                }
            }

            if (mazeId == null)
            {
                throw new Exception("Unable to create new challenge");
            }
            return mazeId;
        }

        internal static async Task<MazeState> GetMazeState(string mazeId)
        {
            MazeState state = null;

            string getMazeStateUrl = string.Format("{0}/{1}", TP_PONY_CHALLENGE_API_URL, mazeId);
            var httpResponse = await Client.GetAsync(getMazeStateUrl);

            if (httpResponse.IsSuccessStatusCode && httpResponse.Content != null)
            {
                string contentStr = await httpResponse.Content.ReadAsStringAsync();
                JObject contentJson = JObject.Parse(contentStr);
                if (contentJson != null)
                {
                    state = new MazeState(contentJson);
                }
            }

            if (state == null)
            {
                throw new Exception("Unable to obtain maze state");
            }
            return state;
        }

        internal static async Task MovePony(string mazeId, Direction direction)
        {
            string movePonyUrl = string.Format("{0}/{1}", TP_PONY_CHALLENGE_API_URL, mazeId);

            JObject directionRequest = new JObject();
            directionRequest.Add("direction", direction.ToString().ToLower());

            StringContent requestBody = new StringContent(JsonConvert.SerializeObject(directionRequest), Encoding.UTF8, "application/json");

            var httpResponse = await Client.PostAsync(movePonyUrl, requestBody);
        }

        internal static async Task<MazeState> MovePonyAndGetState(string mazeId, Direction direction)
        {
            await MovePony(mazeId, direction);

            return await GetMazeState(mazeId);
        }

        internal static async Task<string> GetMazeImage(string mazeId)
        {
            string mazeImageStr = null;

            string getMazeImageUrl = string.Format("{0}/{1}/print", TP_PONY_CHALLENGE_API_URL, mazeId);
            var httpResponse = await Client.GetAsync(getMazeImageUrl);

            if (httpResponse.IsSuccessStatusCode && httpResponse.Content != null)
            {
                mazeImageStr = await httpResponse.Content.ReadAsStringAsync();
            }

            if (mazeImageStr == null)
            {
                throw new Exception("Unable to obtain maze state");
            }
            return mazeImageStr;
        }
    }
}