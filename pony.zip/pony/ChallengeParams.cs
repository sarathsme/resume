﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace PonyChallenge
{
    class ChallengeParams
    {
        [JsonProperty(PropertyName = "maze-height")]
        public int Height { get; set; }

        [JsonProperty(PropertyName = "maze-width")]
        public int Width { get; set; }

        [JsonProperty(PropertyName = "maze-player-name")]
        public string PlayerName { get; set; }

        [JsonProperty(PropertyName = "difficulty")]
        public int Difficulty { get; set; }

        public ChallengeParams(int width, int height, string playerName, int difficulty)
        {
            this.Height = height;
            this.Width = width;
            this.PlayerName = playerName;
            this.Difficulty = difficulty;
        }
    }
}
