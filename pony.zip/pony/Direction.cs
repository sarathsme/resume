﻿namespace PonyChallenge
{
    enum Direction
    {
        North,
        South,
        East,
        West
    }
}