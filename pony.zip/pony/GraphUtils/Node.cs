﻿using System.Collections.Generic;

namespace PonyChallenge.GraphUtils
{
    class Node
    {
        internal int Data;
        internal List<Node> Children;

        internal Node(int data)
        {
            this.Data = data;
            this.Children = new List<Node>();
        }
    }
}
