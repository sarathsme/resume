﻿using System.Collections.Generic;

namespace PonyChallenge.GraphUtils
{
    class Tree
    {
        //Pony's starting position
        internal Node Root;
        internal List<Node> AllNodes;
    }
}
