﻿using PonyChallenge.API;
using System;
using System.Collections.Generic;
using System.Text;

namespace PonyChallenge.ManualMode
{
    //TODO: Display success and failure messages
    class ManualChallenge
    {
        private readonly ChallengeParams challengeParams;
        private string currentMazeId;

        internal ManualChallenge(ChallengeParams challengeParams)
        {
            this.challengeParams = challengeParams;
        }

        internal void StartChallenge()
        {
            createNewChallenge();

            ConsoleKey? keyPressed = null;

            while (keyPressed != ConsoleKey.Escape)
            {
                keyPressed = Console.ReadKey().Key;
                switch (keyPressed)
                {
                    case ConsoleKey.UpArrow: movePonyAndPrint(Direction.North); break;
                    case ConsoleKey.DownArrow: movePonyAndPrint(Direction.South); break;
                    case ConsoleKey.RightArrow: movePonyAndPrint(Direction.East); break;
                    case ConsoleKey.LeftArrow: movePonyAndPrint(Direction.West); break;
                    case ConsoleKey.N: createNewChallenge(); break;
                }
            }
        }

        private void createNewChallenge()
        {
            currentMazeId = PonyChallengeAPI.CreateNewChallenge(challengeParams).Result;
            printMaze();
        }

        private void movePonyAndPrint(Direction direction)
        {
            PonyChallengeAPI.MovePony(currentMazeId, direction).Wait();
            printMaze();
        }

        private void printMaze()
        {
            string instructions = string.Format(
                    "\n{0}\n{1}\n{2}",
                    "Use arrow keys to move the pony",
                    "Press ESC to quit the game",
                    "Press N to start a new challenge"
                );
            string mazeImage = PonyChallengeAPI.GetMazeImage(currentMazeId).Result;
            Console.Clear();
            Console.WriteLine(mazeImage);
            Console.WriteLine(instructions);
        }
    }
}
