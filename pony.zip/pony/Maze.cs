﻿using PonyChallenge.API;
using PonyChallenge.GraphUtils;
using System;
using System.Collections.Generic;

namespace PonyChallenge
{
    //The pony challenge maze always seems to be a tree and not a graph
    class Maze : Tree
    {
        //Assuming that the maze-id may not be a GUID every time.
        private string ID;
        private MazeState CurrentState;

        private int width = 15;
        private int height = 15;

        internal Maze(string mazeId, int mazeWidth, int mazeHeight)
        {
            this.ID = mazeId;
            this.CurrentState = PonyChallengeAPI.GetMazeState(this.ID).Result;
        }

        private void constructTree()
        {
            int root = CurrentState.PonyPostion;
            List<int> path = new List<int>() { root };
            Stack<Tuple<int, int>> nodesToExplore = new Stack<Tuple<int, int>>();
            int currentNode = root;
            int? previousNode = null;

            List<int> possibleNextNodes = new List<int>();
            if (CurrentState.MazeWalls[currentNode] != null && CurrentState.MazeWalls[currentNode].Count > 0)
            {
                if(!CurrentState.MazeWalls[currentNode].Contains("north"))
                {
                    possibleNextNodes.Add(currentNode - width);
                }
                if (!CurrentState.MazeWalls[currentNode].Contains("west"))
                {
                    possibleNextNodes.Add(currentNode - 1);
                }
            }
            if(CurrentState.MazeWalls[currentNode + 1] != null && CurrentState.MazeWalls[currentNode + 1].Count > 0 && !CurrentState.MazeWalls[currentNode + 1].Contains("west"))
            {
                possibleNextNodes.Add(currentNode + 1);
            }
            if (CurrentState.MazeWalls[currentNode + width] != null && CurrentState.MazeWalls[currentNode + width].Count > 0 && !CurrentState.MazeWalls[currentNode + width].Contains("north"))
            {
                possibleNextNodes.Add(currentNode + width);
            }

            if(possibleNextNodes.Count > 1)
            {

            }
        }
    }
}
