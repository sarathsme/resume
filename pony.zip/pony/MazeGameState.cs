﻿using Newtonsoft.Json;

namespace PonyChallenge
{
    class MazeGameState
    {
        [JsonProperty(PropertyName = "state")]
        public string State { get; set; }

        [JsonProperty(PropertyName = "state-result")]
        public string Result { get; set; }
    }
}
