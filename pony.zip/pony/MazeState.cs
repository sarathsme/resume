﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;

namespace PonyChallenge
{
    class MazeState
    {
        public int PonyPostion { get; set; }
        public int DomokunPostion { get; set; }
        public int ExitPosition { get; set; }
        public List<List<string>> MazeWalls;
        public MazeGameState GameState { get; set; }

        public MazeState(JObject stateObj)
        {
            if (stateObj != null)
            {
                if (stateObj["pony"] != null)
                {
                    List<int> ponyPositions = stateObj["pony"].ToObject<List<int>>();
                    if (ponyPositions != null && ponyPositions.Count > 0)
                    {
                        this.PonyPostion = ponyPositions[0];
                    }
                }

                if (stateObj["domokun"] != null)
                {
                    List<int> domokunPostions = stateObj["domokun"].ToObject<List<int>>();
                    if (domokunPostions != null && domokunPostions.Count > 0)
                    {
                        this.DomokunPostion = domokunPostions[0];
                    }
                }

                if (stateObj["end-point"] != null)
                {
                    List<int> endPoints = stateObj["end-point"].ToObject<List<int>>();
                    if (endPoints != null && endPoints.Count > 0)
                    {
                        this.ExitPosition = endPoints[0];
                    }
                }

                if (stateObj["data"] != null)
                {
                    List<List<string>> mazeDoors = stateObj["data"].ToObject<List<List<string>>>();
                    if (mazeDoors != null && mazeDoors.Count > 0)
                    {
                        this.MazeWalls = mazeDoors;
                    }
                }

                if (stateObj["game-state"] != null)
                {
                    this.GameState = stateObj["game-state"].ToObject<MazeGameState>();
                }
            }
            else
            {
                throw new ArgumentNullException("stateObj");
            }

        }
    }
}
