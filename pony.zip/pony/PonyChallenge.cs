﻿using PonyChallenge.API;

namespace PonyChallenge
{
    //Automatically calculate pony path and move the pony
    class PonyChallenge
    {
        private readonly ChallengeParams parameters;
        private Maze ponyMaze;

        internal PonyChallenge(ChallengeParams challengeParams)
        {
            this.parameters = challengeParams;
            string mazeId = PonyChallengeAPI.CreateNewChallenge(challengeParams).Result;
            this.ponyMaze = new Maze(mazeId, challengeParams.Width, challengeParams.Height);
        }
    }
}