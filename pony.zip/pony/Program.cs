﻿using PonyChallenge.API;
using PonyChallenge.ManualMode;
using System;

namespace PonyChallenge
{
    //TODO: Handle manual challenge also
    class Program
    {
        const int DEFAULT_WIDTH = 15;
        const int DEFAULT_HEIGHT = 15;
        const string DEFAULT_NAME = "AppleJack";
        const int DEFAULT_DIFFICULTY = 10;

        static void Main(string[] args)
        {
            ChallengeParams challengeParams = GetChallengeParams(args);
            PonyChallenge automatedChallenge = new PonyChallenge(challengeParams);
            //ManualChallenge chall = new ManualChallenge(challengeParams);
            //chall.StartChallenge();
        }


        static ChallengeParams GetChallengeParams(string[] args)
        {
            //TODO: Get Params from args
            //for (int i = 0; i < args.Length; i++)
            //{
            //}
            return new ChallengeParams(DEFAULT_WIDTH, DEFAULT_HEIGHT, DEFAULT_NAME, DEFAULT_DIFFICULTY);
        }
    }
}
